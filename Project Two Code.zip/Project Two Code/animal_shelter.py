from pymongo import MongoClient
from bson.json_util import dumps

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB (create and read) """


    def __init__(self, username: str='', password: str='') -> None:
        # Initializing the MongoClient to connect to mongodb w/o authentication
        # self.client = MongoClient('mongodb://localhost:46640')
        
        # Initializing the MongoClient to connect to mongodb w/ authentication
        self.client = MongoClient('mongodb://%s:%s@localhost:46640/?authMechanism=DEFAULT&authSource=AAC'%(username, password))
        self.database = self.client['AAC']


    def create(self, data: dict={}) -> bool:
        # Creates a document if a dictionary is passed from the data parameter
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary
            return True
        else:
            raise Exception('Nothing to save, because data parameter is empty')


    def read(self, data: dict={}) -> dict:
        # Returns a dictionary containing the document that matched the query
        doc = self.database.animals.find_one(data) # data should be dictionary
        if doc:
            return doc
        else:
            raise Exception('Document not found')


    def read_all(self, data: dict={}):
        # Returns a ptr to all the documents that matched the query
        cursor = self.database.animals.find(data)
        if cursor:
            return cursor
        else:
            raise Exception('No documents found')


    # Returns the updated document in JSON format if successful, or raises an exception
    def update(self, data: dict={}, update: dict={}):        
        doc = self.database.animals.find_one(data)
        if self.database.animals.update_one(data, update):
            doc = self.database.animals.find_one({'_id':doc.get('_id')})
            return dumps(doc)
        else:
            raise Exception('Update unsuccessful')
    
    
    # Returns the updated documents in JSON format if successful, or raises an exception
    def update_all(self, data: dict={}, update: dict={}): 
        cursor = self.database.animals.find(data)
        if cursor:
            doc_id = list()
            for doc in cursor:
                doc_id.append(doc['_id'])
            self.database.animals.update_many(data, update)
            updated_docs = list()
            for doc in doc_id:
                updated_docs.append(self.database.animals.find_one({'_id':doc}))
            return dumps(updated_docs)
        else:
            raise Exception('Update unsuccessful')


    # Returns the deleted documet in JSON format if successful, or raises an exception
    def delete(self, data:dict={}):
        doc = self.database.animals.find_one(data)
        if doc is not None:
            deleted = self.database.animals.delete_one(data)
            print('DELETE - ',deleted.deleted_count, 'document deleted:')
            return dumps(doc)
        else:
            raise Exception('Delete unsuccessful')     


    # Returns the deleted documet(s) in JSON format if successful, or raises an exception
    def delete_all(self, data: dict={}):
        cursor_list = list(self.database.animals.find(data))
        deleted_docs = self.database.animals.delete_many(data)
        if deleted_docs is not None:
            print('DELETE - ',deleted_docs.deleted_count, 'document(s) deleted:')
            return dumps(cursor_list)
        else:
            raise Exception('Delete unsuccessful')

